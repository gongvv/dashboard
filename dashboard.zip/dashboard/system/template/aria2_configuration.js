//Aria2Ng autoconfig injection
//author: HuangYeWuDeng
//date: 2018-06-27

	(function () {
		'use strict';
		angular.module('ariaNg').run(['$rootScope', '$window', '$location', 'ariaNgSettingService', 'ariaNgConstants', function ($rootScope, $window, $location, ariaNgSettingService, ariaNgConstants) {
			var getDefaultRpcHost = function () {
				var currentHost = $location.$$host;
				if (currentHost) {
					return currentHost;
				}
				return ariaNgConstants.defaultHost;
			};
			console.log($location);
			let protocol = ariaNgSettingService.getCurrentRpcProtocol();
            protocol = protocol == "" ? "http" : protocol;
            let host = ariaNgSettingService.getRpcHost();
            let port = ariaNgSettingService.getRpcPort();
            let secret = ariaNgSettingService.getCurrentRpcSecret();
            let rpc_secure = {{ .aria2cfg.rpc_secure }};
            let local_cfg_last_update = $window.localStorage.getItem("cfg_last_update");
            let server_cfg_last_update = parseInt("{{ .aria2cfg.cfg_last_update }}")
			if (secret == "" || local_cfg_last_update == null || local_cfg_last_update == "" || local_cfg_last_update < server_cfg_last_update) {
                if ($location.$$protocol === "https:" || rpc_secure) {
                    protocol = "https";
                }
                ariaNgSettingService.setRpcProtocol(protocol);
                // ariaNgSettingService.setRpcProtocol("ws");
                ariaNgSettingService.setRpcHost(getDefaultRpcHost());
                ariaNgSettingService.setRpcPort({{ .aria2cfg.rpc_port }});
                ariaNgSettingService.setRpcSecret('{{ .aria2cfg.rpc_secret }}');
                ariaNgSettingService.setLanguage('{{ .aria2cfg.lang }}');
                $window.localStorage.setItem("cfg_last_update", server_cfg_last_update);
				$window.location.reload();
			}
		}]);
	}());